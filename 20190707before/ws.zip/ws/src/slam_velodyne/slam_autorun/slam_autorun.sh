#!/bin/bash

# rosparam delete /
rosparam set slam_path "$(cd $(dirname $0);pwd)/data/"

gnome-terminal -x bash -c   "$(find */slam_monitor_dump.sh)"
sleep 3

gnome-terminal -x bash -c  "roslaunch localization localization_bag.launch"
# gnome-terminal -x bash -c  "roslaunch slam_velodyne slam_velodyne.launch"
sleep 5

gnome-terminal -x bash -c  "roslaunch  zone_management zone_management.launch"
sleep 1

# gnome-terminal -x bash -c  "rosbag play /media/ubuntu/software/rosbags/gtyuanqu_new/all2circle.bag --clock --topics /velodyne_points_with_gps /gnss/raw " 
# sleep 3

rosparam set calibration_result_path "$(cd $(dirname $0);pwd)/data/calibration_result.txt"
echo "The optimal calibration parameters:pending" > $(rosparam get calibration_result_path)
gnome-terminal -x bash -c "watch -n 1 cat $(rosparam get calibration_result_path)"

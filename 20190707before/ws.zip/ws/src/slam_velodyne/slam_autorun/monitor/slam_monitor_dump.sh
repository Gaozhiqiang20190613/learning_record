#!/bin/bash

rosparam set calibration_mode always	#default
# rosparam set calibration_mode once 
rosparam set calibration_state pending
rosparam set calibration_switch enable	#default
# rosparam set calibration_switch disable 
rosparam set time_diff_min_index pending
rosparam set gnss_state good
rosparam set mean_dis pending
rosparam set mean_dis_opt pending
rosparam set mean_dis_selected pending
rosparam set navigation_input pending
rosparam set sample_length pending
rosparam set sample_length_opt pending
rosparam set sample_length_selected pending
rosparam set utm pending
rosparam set vehicle_state pending
rosparam set mean_dis_selected_threshold pending
rosparam set closed_loop_state pending
rosparam set slam_delay pending
rosparam set slam_delay_mean pending
rosparam set word_IO_state pending
rosparam set track_length pending
rosparam set velocity_vehicle pending
rosparam set velocity_gnss pending
rosparam set gear pending
rosparam set boundary_grid_num 1



watch -n 0.1 "
rosparam dump |grep -E  'gnss_state:\
|navigation_input:\
|calibration_state:\
|calibration_mode:\
|calibration_switch:\
|time_diff_min_index:\
|sample_length:\
|sample_length_opt:\
|sample_length_selected:\
|mean_dis:\
|mean_dis_opt:\
|mean_dis_selected:\
|utm:\
|vehicle_state:\
|closed_loop_state:\
|mean_dis_selected_threshold:\
|slam_delay:\
|slam_delay_mean:\
|word_IO_state:\
|track_length:\
|boundary_grid_num:\
|gear:\
|velocity_vehicle:\
|velocity_gnss:\
'
"

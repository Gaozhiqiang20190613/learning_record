# gnome-terminal -x bash -c  "rosbag play /media/ubuntu/software/rosbags/gtyuanqu_new/all2circle.bag --clock --topics /velodyne_points_with_gps /gnss/raw "  

gnome-terminal -x bash -c  "rosbag play /media/ubuntu/software/rosbags/新站点环卫车右侧激光/2019-06-12-17-11-25.bag --clock --topics /velodyne1_points /gnss/raw "  